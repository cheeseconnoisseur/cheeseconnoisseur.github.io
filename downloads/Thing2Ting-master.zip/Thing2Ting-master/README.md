# Thing2Ting
An open source app that translates British English into "Heavy Slang", includes the options to copy to clipboard,share and an in-app word definer that uses "urbandictionary.com"
